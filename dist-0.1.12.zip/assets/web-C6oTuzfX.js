import{W as n}from"./index-dClU1Cru.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};

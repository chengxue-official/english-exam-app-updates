import{W as n}from"./index-CBReri2H.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};

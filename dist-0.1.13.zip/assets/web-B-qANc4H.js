import{W as n}from"./index-Ch9MU31b.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};

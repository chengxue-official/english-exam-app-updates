import{W as n}from"./index-BpPhx-VH.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};

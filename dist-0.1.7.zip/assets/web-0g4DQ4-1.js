import{W as n}from"./index-B7fO0Px0.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};

import{W as n}from"./index-BXQEV5SL.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};

import{W as n}from"./index-BUY_G4wC.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};

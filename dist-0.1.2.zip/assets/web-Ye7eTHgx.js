import{W as n}from"./index-CSW_n6mv.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};

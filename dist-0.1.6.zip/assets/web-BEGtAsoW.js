import{W as n}from"./index-DF9p0l2u.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};

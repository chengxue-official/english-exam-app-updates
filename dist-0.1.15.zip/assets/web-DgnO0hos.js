import{W as n}from"./index-pYb3U8Pp.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};

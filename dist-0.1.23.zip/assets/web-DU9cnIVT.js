import{W as n}from"./index-Cx7dt7PG.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};

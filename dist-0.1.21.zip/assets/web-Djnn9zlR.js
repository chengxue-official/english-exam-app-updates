import{W as n}from"./index-BMRn-kc2.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};

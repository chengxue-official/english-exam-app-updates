import{W as n}from"./index-C8Q4JZ7T.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};

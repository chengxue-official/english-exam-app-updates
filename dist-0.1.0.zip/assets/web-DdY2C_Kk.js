import{W as n}from"./index-47Ri-tSb.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};

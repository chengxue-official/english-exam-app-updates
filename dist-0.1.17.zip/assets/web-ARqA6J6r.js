import{W as n}from"./index-hFQL_c4G.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
